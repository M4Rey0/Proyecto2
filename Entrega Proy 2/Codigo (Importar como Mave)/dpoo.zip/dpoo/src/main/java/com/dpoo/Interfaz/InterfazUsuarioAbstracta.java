package com.dpoo.Interfaz;

import com.dpoo.Entidades.Usuario;
import com.dpoo.Gestores.GestorPrincipal;

public abstract class InterfazUsuarioAbstracta {
	protected InputUtils inputUtils = InputUtils.getInstance();
	protected PrintUtils printUtils = PrintUtils.getInstance();
	
	protected GestorPrincipal gestor = GestorPrincipal.getInstance();
	
	protected Usuario login() {
		
		printUtils.print("Iniciar sesión");
		printUtils.print("");
		
		String username = inputUtils.leerString("Ingrese su nombre de usuario: ");
		String password = inputUtils.leerString("Ingrese su contraseña: ");
		
		Usuario usuario = gestor.iniciarSesion(username, password);
		
		printUtils.print("");
		
		return usuario;
	}
	
	protected abstract void crearUsuario();
}
