package com.dpoo.Interfaz;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.dpoo.Entidades.Usuario;
import com.dpoo.Entidades.actividades.Tarea;
import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.LearningPath;
import com.dpoo.Entidades.usuarios.Estudiante;
import com.dpoo.Entidades.usuarios.Profesor;
import com.dpoo.Gestores.GestorPrincipal;

public class InterfazTest {
    private Scanner scanner = new Scanner(System.in);
    private GestorPrincipal gestorPrincipal = GestorPrincipal.getInstance();
    public void ejecutar(){

    int opcion = -1;
    while (opcion != 0) {
            System.out.println("1. Iniciar sesión");
            System.out.println("2. Crear Estudiante");
            System.out.println("3. Crear Profesor");
            System.out.println("4. Crear Actividad");
            System.out.println("5. Ver Actividades");
            System.out.println("6. Ver Actividades de un Profesor");
            System.out.println("7. Crear LearningPath");
            System.out.println("8. Ver LearningPaths");
            System.out.println("9. Inscribir Estudiante en LearningPath");
            System.out.println("10. Crear Rating");
            System.out.println("11. Ver ratings de una actividad");
            System.out.println("0. Salir");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.println("Iniciar sesión");
                    iniciarSesion();
                    break;
                case 2:
                    System.out.println("Crear Estudiante");
                    crearEstudiante();
                    break;
                case 3:
                    System.out.println("Crear Profesor");
                    crearProfesor();
                    break;
                case 4:
                    System.out.println("Crear Actividad");
                    crearActividad();
                    break;
                case 5:
                    System.out.println("Ver Actividades");
                    verActividades();
                    break;
                case 6:
                    System.out.println("Ver Actividades de un Profesor");
                    verActividadesProfesor();
                    break;
                case 7:
                    System.out.println("Crear LearningPath");
                    crearLearningPath();
                    break;
                case 8:
                    System.out.println("Ver LearningPaths");
                    verLearningPaths();
                    break;
                case 9:
                    System.out.println("Inscribir Estudiante en LearningPath");
                    inscribirEstudianteLearningPath();
                    break;
                case 10:
                    System.out.println("Crear Rating");
                    crearRating();
                    break;
                case 11:
                    System.out.println("Ver ratings de una actividad");
                    verRatings();
                    break;
                case 0:
                    System.out.println("Salir");
                    break;
                default:
                    System.out.println("Opción no válida");
                    break;
            }
        }
    }

    public void iniciarSesion(){
        System.out.println("Iniciar sesión");
        System.out.println("Ingrese su usuario:");
        String username = scanner.nextLine();
        System.out.println("Ingrese su contraseña:");
        String contrasena = scanner.nextLine();
        Usuario usuario = gestorPrincipal.iniciarSesion(username, contrasena);
        if (usuario != null) {
            System.out.println("Bienvenido " + usuario.getNombre());
        } else {
            System.out.println("Usuario o contraseña incorrectos");
        }
    }

    public void crearEstudiante(){
        System.out.println("Crear Estudiante");
        System.out.println("Ingrese su nombre:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese su usuario:");
        String username = scanner.nextLine();
        System.out.println("Ingrese su contraseña:");
        String contrasena = scanner.nextLine();
        Estudiante estudiante = new Estudiante(nombre, username, contrasena);
        gestorPrincipal.crearUsuario(estudiante);
        System.out.println("Estudiante creado exitosamente");
        System.out.println("Id: " + estudiante.getId());
    }

    public void crearProfesor(){
        System.out.println("Crear Profesor");
        System.out.println("Ingrese su nombre:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese su usuario:");
        String username = scanner.nextLine();
        System.out.println("Ingrese su contraseña:");
        String contrasena = scanner.nextLine();
        Profesor profesor = new Profesor(nombre, username, contrasena);
        gestorPrincipal.crearUsuario(profesor);

        System.out.println("Profesor creado exitosamente");
        System.out.println("Id: " + profesor.getId());
    }

    public void crearActividad(){
        System.out.println("Crear Actividad");
        System.out.println("Ingrese el nombre de la tarea");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese la descripción de la tarea");
        String descripcion = scanner.nextLine();
        System.out.println("Ingrese la duración de la tarea");
        int duracion = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Ingrese el nivel de la tarea");
        String nivel = scanner.nextLine();
        System.out.println("Ingrese el objetivo de la tarea");
        String objetivo = scanner.nextLine();
        System.out.println("Ingrese el contenido de la tarea");
        String contenido = scanner.nextLine();
        System.out.println("Ingrese el id del autor de la tarea");
        int autorId = scanner.nextInt();
        scanner.nextLine();

        Actividad tarea = new Tarea(nombre, descripcion, objetivo, nivel, duracion, contenido, autorId);
        gestorPrincipal.agregarActividad(tarea);
        System.out.println("Tarea creada exitosamente");
        System.out.println("Id: " + tarea.getId());
    }

    public void verActividades(){
        System.out.println("Ver Actividades");
        for (Actividad actividad : gestorPrincipal.getActividades().values()) {
            System.out.println("Id: " + actividad.getId());
            System.out.println("Nombre: " + actividad.getNombre());
            System.out.println("Tipo: " + actividad.getTipo());
            System.out.println("Descripción: " + actividad.getDescripcion());
            System.out.println("Duración: " + actividad.getDuracion());
            System.out.println("Nivel: " + actividad.getNivel());
            System.out.println("Objetivo: " + actividad.getObjetivo());
            System.out.println("Autor: " + actividad.getAutorId());
            System.out.println("Contenido: " + actividad.getContenido());
            System.out.println();
        }
    }

    public void verActividadesProfesor(){
        System.out.println("Ver Actividades de un Profesor");
        System.out.println("Ingrese el id del profesor");
        int profesorId = scanner.nextInt();
        scanner.nextLine();
        for (Actividad actividad : gestorPrincipal.getActividadesProfesor(profesorId)) {
            System.out.println("Id: " + actividad.getId());
            System.out.println("Nombre: " + actividad.getNombre());
            System.out.println("Tipo: " + actividad.getTipo());
            System.out.println("Descripción: " + actividad.getDescripcion());
            System.out.println("Duración: " + actividad.getDuracion());
            System.out.println("Nivel: " + actividad.getNivel());
            System.out.println("Objetivo: " + actividad.getObjetivo());
            System.out.println("Contenido: " + actividad.getContenido());
            System.out.println();
        }
        if (gestorPrincipal.getActividadesProfesor(profesorId).isEmpty()) {
            System.out.println("El profesor no tiene actividades");
        }
    }

    public void crearLearningPath(){
        System.out.println("Crear LearningPath");
        System.out.println("Ingrese el nombre del LearningPath");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese la descripción del LearningPath");
        String descripcion = scanner.nextLine();
        System.out.println("Ingrese el id del autor del LearningPath");
        int autorId = scanner.nextInt();
        scanner.nextLine();
        ArrayList<Actividad> actividades = new ArrayList<>();
        int opcion = -1;
        while (opcion != 0) {
            System.out.println("1. Agregar Actividad");
            System.out.println("0. Salir");
            opcion = scanner.nextInt();
            scanner.nextLine();
            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el id de la actividad");
                    int actividadId = scanner.nextInt();
                    scanner.nextLine();
                    Actividad actividad = gestorPrincipal.obtenerActividad(actividadId);
                    if (actividad != null) {
                        actividades.add(actividad);
                    } else {
                        System.out.println("Actividad no encontrada");
                    }
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opción no válida");
                    break;
            }
        }

        LearningPath learningPath = new LearningPath(nombre, descripcion, opcion, LocalDate.now(), LocalDate.now(), 1, autorId);
        for (Actividad actividad : actividades) {
            learningPath.agregarActividad(actividad);
        }

        gestorPrincipal.agregarLearningPath(learningPath);
        System.out.println("LearningPath creado exitosamente");
        System.out.println("Id: " + learningPath.getId());
    }

    public void verLearningPaths(){
        ArrayList<LearningPath> learningPaths = gestorPrincipal.getLearningPaths();
        for (LearningPath path : learningPaths){
            System.out.println("Id: " + path.getId());
            System.out.println("Nombre: " + path.getNombre());
            System.out.println("Descripción: " + path.getDescripcion());
            System.out.println("Duración: " + path.getDuracion());
            System.out.println("Fecha de creación: " + path.getFechaCreacion());
            System.out.println("Fecha de modificación: " + path.getFechaModificacion());
            System.out.println("Version: " + path.getVersion());
            System.out.println("Autor: " + path.getAutor());
            System.out.println("Actividades:");
            for (Actividad actividad : path.getActividades().values()) {
                System.out.println("\tId: " + actividad.getId());
                System.out.println("\tNombre: " + actividad.getNombre());
                System.out.println("\tTipo: " + actividad.getTipo());
                System.out.println("\tDescripción: " + actividad.getDescripcion());
                System.out.println("\tDuración: " + actividad.getDuracion());
                System.out.println("\tNivel: " + actividad.getNivel());
                System.out.println("\tObjetivo: " + actividad.getObjetivo());
                System.out.println("\tAutor: " + actividad.getAutorId());
                System.out.println("\tContenido: " + actividad.getContenido());
                System.out.println();
            }
            System.out.println("Estudiantes:");
            for (int estudiante : path.getEstudiantes()) {
                System.out.println("\tId: " + estudiante);
            }
            System.out.println("\n");
        }
    }

    public void inscribirEstudianteLearningPath(){
        System.out.println("Inscribir Estudiante en LearningPath");
        System.out.println("Ingrese el id del LearningPath");
        int learningPathId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Ingrese el id del estudiante");
        int estudianteId = scanner.nextInt();
        scanner.nextLine();
        gestorPrincipal.inscribirEstudiante(learningPathId, estudianteId);
        System.out.println("Estudiante inscrito exitosamente");
    }

    public void crearRating(){
        System.out.println("Crear Rating");
        System.out.println("Ingrese el id del usuario");
        int estudianteId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Ingrese el id de la actividad");
        int actividadId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Ingrese el rating (tiene que ser un float)");
        float rating = scanner.nextFloat();
        scanner.nextLine();
        gestorPrincipal.agregarRating(actividadId, estudianteId, rating);
        System.out.println("Rating creado exitosamente");
    }

    public void verRatings(){
        System.out.println("Ver ratings de una actividad");
        System.out.println("Ingrese el id de la actividad");
        int actividadId = scanner.nextInt();
        scanner.nextLine();
        HashMap<Integer, Float> ratings = gestorPrincipal.getRatingsActividad(actividadId);
        for (int estudianteId : ratings.keySet()) {
            System.out.println("Id del estudiante: " + estudianteId);
            System.out.println("Rating: " + ratings.get(estudianteId));
        }
    }
}
