package com.dpoo.Entidades.actividades;

import java.util.HashMap;

public class Pregunta {
    private int id;
    private String enunciado;
    private HashMap<Integer, String> opciones = new HashMap<>();
    private int respuestaCorrecta;

    public Pregunta(String enunciado, HashMap<Integer, String> opciones, int respuestaCorrecta) {
        this.enunciado = enunciado;
        this.opciones = opciones;
        this.respuestaCorrecta = respuestaCorrecta;
    }

    @Override
    public String toString(){
        String retorno = enunciado + "\n";
        for (Integer key : opciones.keySet()) {
            retorno = retorno + "\t" + key + ". " + opciones.get(key) + "\n";
        }
        retorno = retorno + respuestaCorrecta + "\n";
        retorno = retorno + "$";
        return retorno;
    }

    public boolean verificarRespuesta(int respuesta) {
        return respuesta == respuestaCorrecta;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public HashMap<Integer, String> getOpciones() {
        return opciones;
    }

    public void setOpciones(HashMap<Integer, String> opciones) {
        this.opciones = opciones;
    }

    public int getRespuestaCorrecta() {
        return respuestaCorrecta;
    }

    public void setRespuestaCorrecta(int respuestaCorrecta) {
        this.respuestaCorrecta = respuestaCorrecta;
    }
    
	public static Pregunta fromString(String preguntaString) {
		String[] partes = preguntaString.split("\n");
		String enunciado = partes[0];
		HashMap<Integer, String> opciones = new HashMap<>();
		for (int i = 1; i < partes.length - 2; i++) {
			String[] opcion = partes[i].split(". ");
			String numero = opcion[0].replace("\t", "");
			opciones.put(Integer.parseInt(numero), opcion[1]);
		}
		int respuestaCorrecta = Integer.parseInt(partes[partes.length - 2]);
		Pregunta pregunta = new Pregunta(enunciado, opciones, respuestaCorrecta);
		return pregunta;
	}
}
