package com.dpoo.Interfaz;

import java.util.Scanner;

public class InputUtils {
	private Scanner scanner = new Scanner(System.in);
	
	private static InputUtils instance = null;
	
	private InputUtils() {
	}
	
	public static InputUtils getInstance() {
		if (instance == null) {
			instance = new InputUtils();
		}
		return instance;
	}
	
	public int leerEntero(String mensaje) {
		System.out.print(mensaje);
		while (!scanner.hasNextInt()) {
			System.out.println("Por favor, ingrese un número válido: ");
			scanner.next();
		}
		int valor = scanner.nextInt();
		scanner.nextLine();
		return valor;
	}
	
	public float leerFloat(String mensaje) {
		System.out.print(mensaje);
		while (!scanner.hasNextFloat()) {
			System.out.print("Por favor, ingrese un número válido: ");
			scanner.next();
		}
		float valor = scanner.nextFloat();
		scanner.nextLine();
		return valor;
	}
	
	public String leerString(String mensaje) {
		System.out.print(mensaje);
		return scanner.nextLine();
	}
	
	/**
	 * Lee un booleano del usuario. Si el usuario ingresa 'si', retorna 1. Si el usuario ingresa 'no', retorna 2.
	 * @param mensaje
	 * @return
	 */
	public int leerBoolean(String mensaje) {
		System.out.println(mensaje);
		System.out.println("Ingrese 'si' o 'no': ");
		boolean checking = true;
		while (checking) {
			String valor = scanner.nextLine();
			if (valor.equalsIgnoreCase("si")) {
				return 1;
			} else if (valor.equalsIgnoreCase("no")) {
				return 2;
			} else {
				System.out.print("Por favor, ingrese 'si' o 'no': ");
			}
		}
		
		return 2;
	}
	
	public String leerParrafo(String mensaje) {
		System.out.println(mensaje);
		System.out.println("Ingrese un valor vacío para terminar el párrafo.");
		String respuesta = "";
		String linea = "";
		boolean corriendo = true;
		
		while (corriendo) {
			linea = scanner.nextLine();
			if (linea.equals("")) {
				corriendo = false;
			} else {
				respuesta += linea + "\n";
			}
		}
		
		System.out.println(respuesta);
		return respuesta;
		
	}
}
