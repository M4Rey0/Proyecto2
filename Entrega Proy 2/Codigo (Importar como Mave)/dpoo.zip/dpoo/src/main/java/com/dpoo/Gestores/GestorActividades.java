package com.dpoo.Gestores;

import java.util.ArrayList;
import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.actividades.Tarea;
import com.dpoo.Persistencia.actividades.PersistenciaActividades;
import com.dpoo.Persistencia.estructuras.PersistenciaRatings;

public class GestorActividades {
    private HashMap<Integer, Actividad> actividades = new HashMap<>();
    private HashMap<Integer, ArrayList<Integer>> actividadesPorAutorId = new HashMap<>();  
    private HashMap<Integer, HashMap<Integer, Float>> ratings = new HashMap<>();
    //Estructura de ratings: <actividadId, <usuarioId, rating>>

    public void agregarActividad(Actividad actividad) {
        actividades.put(actividad.getId(), actividad);
        if (!actividadesPorAutorId.containsKey(actividad.getAutorId())) {
            ArrayList<Integer> actividadesAutor = new ArrayList<>();
            actividadesAutor.add(actividad.getId());
            actividadesPorAutorId.put(actividad.getAutorId(), actividadesAutor);
        } else {
        	ArrayList<Integer> actividadesAutor = actividadesPorAutorId.get(actividad.getAutorId());
			if (!actividadesAutor.contains(actividad.getId())) {
				actividadesAutor.add(actividad.getId());
				actividadesPorAutorId.put(actividad.getAutorId(), actividadesAutor);
			}
        }

        PersistenciaActividades.guardarActividad(actividad);
    }

    public void agregarRating(int actividadId, int usuarioId, float rating) {
        if (!ratings.containsKey(actividadId)) {
            ratings.put(actividadId, new HashMap<>());
        }
        ratings.get(actividadId).put(usuarioId, rating);
        PersistenciaRatings.guardarRatings(actividadId, ratings.get(actividadId));
    }

    public float obtenerRating(int actividadId, int usuarioId) {
        if (ratings.containsKey(actividadId) && ratings.get(actividadId).containsKey(usuarioId)) {
            return ratings.get(actividadId).get(usuarioId);
        }
        return -1;
    }

    public void quitarActividad(int actividadId) {
        Actividad remover = actividades.get(actividadId);
        actividades.remove(actividadId);
        actividadesPorAutorId.get(remover.getAutorId()).remove(actividadId);
        ratings.remove(actividadId);
        remover = null;
    }

    public Actividad obtenerActividad(int id) {
        return actividades.get(id);
    }

    public static void main(String[] args) {
        GestorActividades gestorActividades = new GestorActividades();
        Actividad actividad = new Tarea("tarea", "hacer la tarea", "terminar la tarea", "principiante", 15, "1 + 1 = ?", 1);
        gestorActividades.agregarActividad(actividad);
        System.out.println(gestorActividades.obtenerActividad(1).toString());
    }

    public void cargarActividades() {
        actividades = PersistenciaActividades.cargarActividades();
        for (Actividad actividad : actividades.values()) {
            if (!actividadesPorAutorId.containsKey(actividad.getAutorId())) {
                ArrayList<Integer> actividadesAutor = new ArrayList<>();
                actividadesAutor.add(actividad.getId());
                actividadesPorAutorId.put(actividad.getAutorId(), actividadesAutor);
            } else {
                actividadesPorAutorId.get(actividad.getAutorId()).add(actividad.getId());
            }

            ratings.put(actividad.getId(), PersistenciaRatings.cargarRatings(actividad.getId()));
        }
    }

    public HashMap<Integer, Actividad> getActividades() {
        return actividades;
    }

    public void setActividades(HashMap<Integer, Actividad> actividades) {
        this.actividades = actividades;
    }

    public HashMap<Integer, ArrayList<Integer>> getActividadesPorAutorId() {
        return actividadesPorAutorId;
    }

    public void setActividadesPorAutorId(HashMap<Integer, ArrayList<Integer>> actividadesPorAutorId) {
        this.actividadesPorAutorId = actividadesPorAutorId;
    }

    public HashMap<Integer, HashMap<Integer, Float>> getRatings() {
        return ratings;
    }

    public void setRatings(HashMap<Integer, HashMap<Integer, Float>> ratings) {
        this.ratings = ratings;
    }
}
