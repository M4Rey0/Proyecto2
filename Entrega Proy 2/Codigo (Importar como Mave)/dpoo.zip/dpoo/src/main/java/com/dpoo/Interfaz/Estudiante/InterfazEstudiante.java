package com.dpoo.Interfaz.Estudiante;

import java.util.ArrayList;
import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.LearningPath;
import com.dpoo.Entidades.Usuario;
import com.dpoo.Entidades.usuarios.Estudiante;
import com.dpoo.Estructuras.ProgresoLearningPath;
import com.dpoo.Interfaz.InterfazUsuarioAbstracta;

public class InterfazEstudiante extends InterfazUsuarioAbstracta {
	
	private Estudiante estudianteActual;
	
	public static void main(String[] args) {
		InterfazEstudiante interfaz = new InterfazEstudiante();
		interfaz.iniciar();
		interfaz.menuPrincipal();
	}
	
	public void iniciar() {
		printUtils.print("Bienvenido al sistema de aprendizaje!");
		printUtils.print("Desea iniciar sesión o crear un nuevo usuario?");
		printUtils.print("1. Iniciar sesión");
		printUtils.print("2. Crear usuario");
		
		while (true) {
			int opcion = inputUtils.leerEntero("Ingrese la opción deseada: ");
			if (opcion == 1) {
                iniciarSesion();
                break;
            } else if (opcion == 2) {
                crearUsuario();
                iniciarSesion();
                break;
            } else {
                printUtils.printError("Opción inválida");
            }
		}
		
	}
	
	@Override
	protected void crearUsuario() {
		String nombre = inputUtils.leerString("Ingrese su nombre: ");
		String username = inputUtils.leerString("Ingrese su nombre de usuario: ");
		String password = inputUtils.leerString("Ingrese su contraseña: ");
		
		Usuario usuario = new Estudiante(nombre, username, password);
		gestor.crearUsuario(usuario);
	}
	
	private void iniciarSesion() {
		boolean loginExitoso = false;
		while (!loginExitoso) {
			Usuario usuario = login();
			
			if (usuario == null) {
				printUtils.printError("Usuario o contraseña incorrectos, vuelva a intentar");
				continue;
			}
			
			if (usuario.getTipo().equals("Estudiante")) {
				this.estudianteActual = (Estudiante) usuario;
				printUtils.print("Bienvenido " + estudianteActual.getNombre());
				printUtils.print("");
				loginExitoso = true;
			} else {
				printUtils.printError("El usuario no es un estudiante, vuelvalo a intentar");
			}
		}
	}

	public void menuPrincipal() {
		int opcion = -1;
		boolean running = true;
		
		while (running) {
			printUtils.print("Bienvenido al sistema de aprendizaje!");
			printUtils.print("1. Ver Learning Paths disponibles");
			printUtils.print("2. Inscribirse a un Learning Path");
			printUtils.print("3. Ver learning paths inscritos");
			printUtils.print("4. Realizar una actividad de un LearningPath");
			printUtils.print("5. Calificar una actividad");
			printUtils.print("6. Ver progreso en un Learning Path");
			printUtils.print("0. Salir");
			printUtils.print("");

			opcion = inputUtils.leerEntero("Ingrese la opción deseada: ");
			printUtils.print("");
			
			switch (opcion) {
				case 1:
					verLearningPaths();
					break;
				case 2:
					inscribirseLearningPath();
					break;
				case 3:
					verLearningPathsInscritos();
					break;
				case 4:
					realizarActividad();
					break;
				case 5:
					calificarActividad();
					break;
				case 6:
					verProgreso();
					break;
				case 0:
					printUtils.print("Hasta luego!");
					running = false;
					break;
				default:
					printUtils.printError("Opción inválida");
					break;
			}
		}
	}

	private void verLearningPathsInscritos() {
		ArrayList<Integer> learningPathsInscritos = estudianteActual.getLearningPaths();
		if (learningPathsInscritos.size() == 0) {
			printUtils.print("No está inscrito a ningún Learning Path");
		} else {
			printUtils.print("Learning Paths inscritos:");
			for (Integer idLearningPath : learningPathsInscritos) {
				LearningPath learningPath = gestor.obtenerLearningPath(idLearningPath);
				printUtils.printPreviewLearningPath(learningPath);
				printUtils.print("");
			}
		}
	}

	private void verProgreso() {
		int idLearningPath = inputUtils.leerEntero("Ingrese el ID del Learning Path del que desea ver su progreso: ");
		ProgresoLearningPath progreso = gestor.getProgresoEstudiante(estudianteActual.getId(), idLearningPath);
		
		if (progreso == null) {
			printUtils.printError("No se encontró el Learning Path o no está inscrito");
			return;
		}
		
		printUtils.print("Progreso en el Learning Path:");
		
		printUtils.print("Progreso total: " + progreso.getProgreso() + "%");
		
		HashMap<Integer, ArrayList<Integer>> mapaProgreso = new HashMap<>();
		
		for (Integer idActividad : progreso.getProgresoPorActividad().keySet()) {
			int progresoActividad = progreso.getProgresoPorActividad().get(idActividad);
			if (!mapaProgreso.containsKey(progresoActividad)) {
				mapaProgreso.put(progresoActividad, new ArrayList<>());
			}
			mapaProgreso.get(progresoActividad).add(idActividad);
		}
		
		printUtils.print("Actividades completadas:");
		printUtils.print("");
		if (mapaProgreso.containsKey(2)) {
			for (Integer idActividad : mapaProgreso.get(2)) {
				Actividad actividad = gestor.obtenerActividad(idActividad);
				printUtils.printPreviewActividad(actividad);
				printUtils.print("");
			}
		}
		
		printUtils.print("Actividades en revisión:");
		printUtils.print("");
		if (mapaProgreso.containsKey(1)) {
			for (Integer idActividad : mapaProgreso.get(1)) {
				Actividad actividad = gestor.obtenerActividad(idActividad);
				printUtils.printPreviewActividad(actividad);
				printUtils.print("");
			}
		}
		
		printUtils.print("Actividades pendientes:");
		printUtils.print("");
		if (mapaProgreso.containsKey(0)) {
			for (Integer idActividad : mapaProgreso.get(0)) {
				Actividad actividad = gestor.obtenerActividad(idActividad);
				printUtils.printPreviewActividad(actividad);
				printUtils.print("");
			}
		}
		
	}

	private void calificarActividad() {
		int idActividad = inputUtils.leerEntero("Ingrese el ID de la actividad que desea calificar: ");
		Actividad actividad = gestor.obtenerActividad(idActividad);
		if (actividad == null) {
			printUtils.printError("Actividad no encontrada");
			return;
		}
		
		float calificacion = inputUtils.leerFloat("Ingrese la calificación de la actividad: ");
		if (calificacion < 0 || calificacion > 5) {
			printUtils.printError("La calificación debe estar entre 0 y 5");
			return;
		}
		
		gestor.agregarRating(idActividad, estudianteActual.getId(), calificacion);
		printUtils.print("Calificación agregada!");
	}

	private void realizarActividad() {
		boolean validacion = false;
		
		LearningPath lp = null;
		
		while (!validacion) {
			int idLearningPath = inputUtils.leerEntero("Ingrese el ID del Learning Path al que desea realizar una actividad: ");
			lp = gestor.obtenerLearningPath(idLearningPath);
			if (lp == null) {
				printUtils.printError("El Learning Path no existe, intente de nuevo");
			} else {
				ArrayList<Integer> learningPathsInscritos = estudianteActual.getLearningPaths();
				if (!learningPathsInscritos.contains(idLearningPath)) {
					printUtils.printError("No está inscrito a este Learning Path, intente de nuevo");
				} else {
					validacion = true;
				}
			}
		}
		
		printUtils.print("Actividades disponibles:");
		ArrayList<Integer> actividadesPosibles = new ArrayList<>();
		for (Integer idActividad : lp.getActividades().keySet()) {
			
			if (!gestor.verificarActividadCompletada(lp.getId(), estudianteActual.getId(), idActividad)) {
				actividadesPosibles.add(idActividad);
				printUtils.printPreviewActividad(gestor.obtenerActividad(idActividad));
				printUtils.print("");
			}
		}
		
		validacion = false;
		
		while (!validacion) {
			int idActividad = inputUtils.leerEntero("Ingrese el ID de la actividad que desea realizar: ");
			if (!actividadesPosibles.contains(idActividad)) {
				printUtils.printError("Actividad inválida, intente de nuevo");
			} else {
				completarActividad(lp.getId(), idActividad);
				validacion = true;
			}
		}
	}
	
	private void completarActividad(int idLearningPath, int idActividad) {
		Actividad actividad = gestor.obtenerActividad(idActividad);
		printUtils.printDetalleActividad(actividad);
		
		if (actividad.necesitaRespuesta()) {
			String respuesta = inputUtils.leerParrafo("Ingrese su respuesta: ");
            gestor.responderActividad(idLearningPath, estudianteActual.getId(), idActividad, respuesta);
        } else {
            printUtils.print("Actividad completada!");
            gestor.completarActividadLearningPath(idLearningPath, estudianteActual.getId(), idActividad);
		}
	}

	private void inscribirseLearningPath() {
		int idLearningPath = inputUtils.leerEntero("Ingrese el ID del Learning Path al que desea inscribirse: ");
		LearningPath learningPath = gestor.obtenerLearningPath(idLearningPath);
		printUtils.print("¿Desea inscribirse al siguiente learning path?");
		printUtils.printDetalleLearningPath(learningPath);
		printUtils.print("");
		int confirmacion = inputUtils.leerBoolean("Confirme si quiere inscribirse");
		if (confirmacion == 1) {
			gestor.inscribirEstudiante(idLearningPath, estudianteActual.getId());
			printUtils.print("Inscripción exitosa!");
		} else {
			printUtils.print("Inscripción cancelada");
		}
	}

	private void verLearningPaths() {
		
		printUtils.print("Learning Paths disponibles:");
		
		ArrayList<LearningPath> learningPaths = gestor.getLearningPaths();
		ArrayList<Integer> learningPathsInscritos = estudianteActual.getLearningPaths();
		
		for (LearningPath learningPath : learningPaths) {
			if (!learningPathsInscritos.contains(learningPath.getId())) {
				printUtils.printPreviewLearningPath(learningPath);
				printUtils.print("");
			}
		}
	}
	
}
