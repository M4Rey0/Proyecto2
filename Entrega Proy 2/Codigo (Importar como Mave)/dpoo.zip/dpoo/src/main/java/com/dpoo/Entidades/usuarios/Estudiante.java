package com.dpoo.Entidades.usuarios;

import java.util.ArrayList;

import com.dpoo.Entidades.Usuario;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Estudiante extends Usuario {

    private ArrayList<Integer> learningPaths = new ArrayList<>();

    public Estudiante(int id, String nombre, String username, String password) {
        super(id, nombre, username, password);
    }

    public Estudiante(String nombre, String username, String password) {
        super(nombre, username, password);
    }

    public void addLearningPath(int id) {
        learningPaths.add(id);
    }

    public void removeLearningPath(int id) {
		for (int i = 0; i < learningPaths.size(); i++) {
			if (learningPaths.get(i) == id) {
				learningPaths.remove(i);
				return;
			}
		}
    }

    @Override
    public String getTipo() {
        return "Estudiante";
    }

    @Override
    public String toString() {
        String formato = super.toString();
        formato += "Estudiante\n";
        for (Integer learningPath : learningPaths) {
            formato += learningPath + "\n";
        }

        return formato;
    }

	public ArrayList<Integer> getLearningPaths() {
		return learningPaths;
	}
}
