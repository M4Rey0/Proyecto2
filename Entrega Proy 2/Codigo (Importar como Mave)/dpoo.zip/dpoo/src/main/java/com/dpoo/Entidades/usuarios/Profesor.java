package com.dpoo.Entidades.usuarios;

import java.util.ArrayList;
import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.Usuario;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Profesor extends Usuario{
    private ArrayList<Actividad> actividadesCreadas = new ArrayList<>();

    public Profesor(int id, String nombre, String username, String password) {
        super(id, nombre, username, password);
    }

    public Profesor(String nombre, String username, String password) {
        super(nombre, username, password);
    }

    public void addActividad(Actividad actividad) {
		if (!actividadesCreadas.contains(actividad)) {
			actividadesCreadas.add(actividad);
		} else {
			int index = actividadesCreadas.indexOf(actividad);
			actividadesCreadas.set(index, actividad);
		}
    }

    public void removeActividad(Actividad actividad) {
        actividadesCreadas.remove(actividad);
    }

    @Override
    public String getTipo() {
        return "Profesor";
    }

    @Override
    public String toString(){
        String formato = super.toString();
        formato += "Profesor\n";
        for (Actividad actividad : actividadesCreadas) {
            formato += actividad.getId() + "\n";
        }

        return formato;
    }

	public ArrayList<Actividad> getActividadesCreadas() {
		return actividadesCreadas;
	}
}
