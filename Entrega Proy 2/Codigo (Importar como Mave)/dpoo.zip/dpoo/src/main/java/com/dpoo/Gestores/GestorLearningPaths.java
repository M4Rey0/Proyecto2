package com.dpoo.Gestores;

import java.util.ArrayList;
import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.LearningPath;
import com.dpoo.Entidades.usuarios.Estudiante;
import com.dpoo.Estructuras.ProgresoLearningPath;
import com.dpoo.Persistencia.actividades.PersistenciaLearningPaths;
import com.dpoo.Persistencia.estructuras.PersistenciaProgreso;

public class GestorLearningPaths {
    private HashMap<Integer, LearningPath> learningPaths = new HashMap<>();
    private HashMap<Integer, ArrayList<Integer>> estudiantesInscritos = new HashMap<>();
    private HashMap<Integer, HashMap<Integer, ProgresoLearningPath>> progresoEstudiantes = new HashMap<>();
    //Estructura de estudiantesInscritos: <learningPathId, ArrayList<estudianteId>>

    public void agregarLearningPath(LearningPath learningPath) {
        learningPaths.put(learningPath.getId(), learningPath);
        estudiantesInscritos.put(learningPath.getId(), new ArrayList<>());
        PersistenciaLearningPaths.guardarLearningPath(learningPath);
    }

    public void inscribirEstudiante(int learningPathId, int estudianteId, boolean carga) {
        if (!estudiantesInscritos.containsKey(learningPathId)) {
            estudiantesInscritos.put(learningPathId, new ArrayList<>());
        }
        estudiantesInscritos.get(learningPathId).add(estudianteId);
        LearningPath learningPath = learningPaths.get(learningPathId);
        if (!progresoEstudiantes.containsKey(learningPathId)) {
            progresoEstudiantes.put(learningPathId, new HashMap<>());
        }
        progresoEstudiantes.get(learningPath.getId()).put(estudianteId, new ProgresoLearningPath(learningPath, estudianteId));
        learningPath.agregarEstudiante(estudianteId);
        
        if (!carga) {
            PersistenciaLearningPaths.guardarLearningPath(learningPath);
            PersistenciaProgreso.guardarProgreso(progresoEstudiantes.get(learningPath.getId()).get(estudianteId));
        }
    }

    public void desinscribirEstudiante(int learningPathId, int estudianteId) {
        if (estudiantesInscritos.containsKey(learningPathId)) {
            estudiantesInscritos.get(learningPathId).remove(estudianteId);
        }
    }

    public ArrayList<Integer> obtenerEstudiantesInscritos(int learningPathId) {
        if (estudiantesInscritos.containsKey(learningPathId)) {
            return estudiantesInscritos.get(learningPathId);
        }
        return new ArrayList<>();
    }

    public LearningPath obtenerLearningPath(int learningPathId) {
        return learningPaths.get(learningPathId);
    }

    public ProgresoLearningPath obtenerProgresoEstudiante(int idEstudiante, int idLearningPath){
        if (!progresoEstudiantes.containsKey(idLearningPath)) {
            progresoEstudiantes.put(idLearningPath, new HashMap<>());
        }
        if (!progresoEstudiantes.get(idLearningPath).containsKey(idEstudiante)) {
            progresoEstudiantes.get(idLearningPath).put(idEstudiante, new ProgresoLearningPath(learningPaths.get(idLearningPath), idEstudiante));
        }
        return progresoEstudiantes.get(idLearningPath).get(idEstudiante);
    }

    public void agregarActividadALearningPath(Actividad actividad, int idLearningPath) {
        learningPaths.get(idLearningPath).agregarActividad(actividad);
        
		if (!estudiantesInscritos.containsKey(idLearningPath)) {
			estudiantesInscritos.put(idLearningPath, new ArrayList<>());
		}
        
		for (Integer estudianteId : estudiantesInscritos.get(idLearningPath)) {
			progresoEstudiantes.get(idLearningPath).get(estudianteId).cambiarProgresoActividad(actividad.getId(), 0);
			PersistenciaProgreso.guardarProgreso(progresoEstudiantes.get(idLearningPath).get(estudianteId));
		}
        PersistenciaLearningPaths.guardarLearningPath(learningPaths.get(idLearningPath));
    }

    public void quitarActividadDeLearningPath(int actividadId, int idLearningPath) {
        learningPaths.get(idLearningPath).removerActividad(actividadId);
		for (Integer estudianteId : estudiantesInscritos.get(idLearningPath)) {
			progresoEstudiantes.get(idLearningPath).get(estudianteId).quitarProgresoActividad(actividadId);
			PersistenciaProgreso.guardarProgreso(progresoEstudiantes.get(idLearningPath).get(estudianteId));
		}
		PersistenciaLearningPaths.guardarLearningPath(learningPaths.get(idLearningPath));
    }

    public void borrarLearningPath(int id) {
        learningPaths.remove(id);
        estudiantesInscritos.remove(id);
        progresoEstudiantes.remove(id);
    }

    public void cambiarProgresoActividad(int idLearningPath, int actividadId, int estudianteId, int progreso) {
        if (progresoEstudiantes.containsKey(idLearningPath) && progresoEstudiantes.get(idLearningPath).containsKey(estudianteId)) {
            progresoEstudiantes.get(idLearningPath).get(estudianteId).cambiarProgresoActividad(actividadId, progreso);
        }
        PersistenciaProgreso.guardarProgreso(progresoEstudiantes.get(idLearningPath).get(estudianteId));
    }

    public void cargarLearningPaths(HashMap<Integer, Actividad> actividades, HashMap<Integer, Estudiante> estudiantes) {
        learningPaths = PersistenciaLearningPaths.cargarLearningPaths(actividades);
        for (LearningPath learningPath : learningPaths.values()) {
            for (Integer estudianteId : learningPath.getEstudiantes()) {
                if (!estudiantesInscritos.containsKey(learningPath.getId())) {
                    estudiantesInscritos.put(learningPath.getId(), new ArrayList<>());
                }
                estudiantesInscritos.get(learningPath.getId()).add(estudianteId);
            }
        }
        ArrayList<ProgresoLearningPath> progresos = PersistenciaProgreso.cargarProgresos(learningPaths, estudiantes);
        for (ProgresoLearningPath progreso : progresos) {
            if (!progresoEstudiantes.containsKey(progreso.getLearningPath().getId())) {
                progresoEstudiantes.put(progreso.getLearningPath().getId(), new HashMap<>());
            }
            progresoEstudiantes.get(progreso.getLearningPath().getId()).put(progreso.getEstudiante(), progreso);
        }
    }
    
	public void agregarPrerrequisito(int idLearningPath, int idActividad, int idPrerrequisito) {
		learningPaths.get(idLearningPath).agregarPrerrequisito(idActividad, idPrerrequisito);
	}

    public HashMap<Integer, LearningPath> getLearningPaths() {
        return learningPaths;
    }

    public void setLearningPaths(HashMap<Integer, LearningPath> learningPaths) {
        this.learningPaths = learningPaths;
    }

    public HashMap<Integer, ArrayList<Integer>> getEstudiantesInscritos() {
        return estudiantesInscritos;
    }

    public void setEstudiantesInscritos(HashMap<Integer, ArrayList<Integer>> estudiantesInscritos) {
        this.estudiantesInscritos = estudiantesInscritos;
    }

    public HashMap<Integer, HashMap<Integer, ProgresoLearningPath>> getProgresoEstudiantes() {
        return progresoEstudiantes;
    }

    public void setProgresoEstudiantes(HashMap<Integer, HashMap<Integer, ProgresoLearningPath>> progresoEstudiantes) {
        this.progresoEstudiantes = progresoEstudiantes;
    }

	public boolean verificarPrerrequisitos(int learningPathId, int estudianteId, int actividadId) {
		ProgresoLearningPath progreso = progresoEstudiantes.get(learningPathId).get(estudianteId);
		LearningPath learningPath = learningPaths.get(learningPathId);
		ArrayList<Integer> prerrequisitos = learningPath.getPrerrequisitos().get(actividadId);
		
		if (prerrequisitos == null) {
			return true;
		}
		
		for (Integer prerrequisito : prerrequisitos) {
			if (progreso.getProgresoPorActividad().get(prerrequisito) != 2) {
				return false;
			}
		}
		
		return true;
	}

	public void responderActividad(int idLearningPath, int idEstudiante, int idActividad, String respuesta) {
		ProgresoLearningPath progreso = progresoEstudiantes.get(idLearningPath).get(idEstudiante);
		progreso.agregarRespuesta(idActividad, respuesta);
		PersistenciaProgreso.guardarProgreso(progreso);
	}

	public String verRespuestasActividad(int idLearningPath, int idEstudiante, int idActividad) {
		ProgresoLearningPath progreso = progresoEstudiantes.get(idLearningPath).get(idEstudiante);
        return progreso.getRespuestaPorActividad(idActividad);
	}

	public Boolean verificarActividadCompletada(int idLearningPath, int idEstudiante, int idActividad) {
		ProgresoLearningPath progreso = progresoEstudiantes.get(idLearningPath).get(idEstudiante);
        return progreso.verificarActividadCompletada(idActividad);
	}
}
