package com.dpoo.Gestores;

import java.util.ArrayList;
import java.util.HashMap;
import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.LearningPath;
import com.dpoo.Entidades.Usuario;
import com.dpoo.Entidades.usuarios.Profesor;
import com.dpoo.Estructuras.ProgresoLearningPath;

public class GestorPrincipal {
    private static GestorPrincipal instance = null;
    private GestorUsuarios gestorUsuarios = new GestorUsuarios();
    private GestorActividades gestorActividades = new GestorActividades();
    private GestorLearningPaths gestorLearningPaths = new GestorLearningPaths();

    private GestorPrincipal() {
        gestorActividades = new GestorActividades();
        gestorActividades.cargarActividades();
        gestorUsuarios = new GestorUsuarios();
        gestorUsuarios.cargarUsuarios(gestorActividades.getActividades());
        gestorLearningPaths = new GestorLearningPaths();
        gestorLearningPaths.cargarLearningPaths(gestorActividades.getActividades(), gestorUsuarios.getEstudiantes());
    }

    public static GestorPrincipal getInstance() {
        if (instance == null) {
            instance = new GestorPrincipal();
        }
        return instance;
    }

    public void crearUsuario(Usuario usuario) {
        gestorUsuarios.agregarUsuario(usuario);
    }

    public void borrarUsuario(int id) {
        gestorUsuarios.borrarUsuario(id);
    }

    public void agregarActividad(Actividad actividad) {
        gestorActividades.agregarActividad(actividad);
        gestorUsuarios.agregarActividad(actividad.getAutorId(), actividad);
    }

    public void agregarLearningPath(LearningPath learningPath) {
        gestorLearningPaths.agregarLearningPath(learningPath);
    }

    public void inscribirEstudiante(int learningPathId, int estudianteId) {
        gestorLearningPaths.inscribirEstudiante(learningPathId, estudianteId, false);
        gestorUsuarios.inscribirEstudianteLearningPath(estudianteId, learningPathId);
    }

    public void desinscribirEstudiante(int learningPathId, int estudianteId) {
        gestorLearningPaths.desinscribirEstudiante(learningPathId, estudianteId);
    }

    public void agregarRating(int actividadId, int usuarioId, float rating) {
        gestorActividades.agregarRating(actividadId, usuarioId, rating);
    }

    public float obtenerRating(int actividadId, int usuarioId) {
        return gestorActividades.obtenerRating(actividadId, usuarioId);
    }

    public HashMap<Integer, Float> getRatingsActividad(int idActividad) {
        return gestorActividades.getRatings().get(idActividad);
    }

    public void agregarActividadALearningPath(Actividad actividad, int idLearningPath) {
        gestorLearningPaths.agregarActividadALearningPath(actividad, idLearningPath);
    }

    public void quitarActividadDeLearningPath(int actividadId, int idLearningPath) {
        gestorLearningPaths.quitarActividadDeLearningPath(actividadId, idLearningPath);
    }

    public void borrarActividad(int actividadId) {
        Actividad actividad = gestorActividades.obtenerActividad(actividadId);
        gestorActividades.quitarActividad(actividadId);
        gestorUsuarios.quitarActividad(actividadId, actividad);
        actividad = null;
    }

    public Actividad obtenerActividad(int id) {
        return gestorActividades.obtenerActividad(id);
    }

    public LearningPath obtenerLearningPath(int learningPathId) {
        return gestorLearningPaths.obtenerLearningPath(learningPathId);
    }

    public Usuario obtenerUsuario(int id) {
        return gestorUsuarios.obtenerUsuario(id);
    }

    public void completarActividadLearningPath(int idLearningPath, int idEstudiante, int idActividad) {
        gestorLearningPaths.cambiarProgresoActividad(idLearningPath, idActividad, idEstudiante, 2);
    }
    
	public ProgresoLearningPath getProgresoEstudiante(int idEstudiante, int idLearningPath) {
		return gestorLearningPaths.obtenerProgresoEstudiante(idEstudiante, idLearningPath);
	}

    public Usuario iniciarSesion(String username, String password) {
        return gestorUsuarios.validarUsuario(username, password);
    }
    
    public HashMap<Integer, Actividad> getActividades() {
        return gestorActividades.getActividades();
    }

    public ArrayList<Actividad> getActividadesProfesor(int profesorId) {
        Profesor profesor = gestorUsuarios.obtenerProfesor(profesorId);
        ArrayList<Actividad> actividades = new ArrayList<>();
        if (profesor == null) {
            return actividades;
        }
        for (Actividad actividad : profesor.getActividadesCreadas()) {
            actividades.add(actividad);
        }

        return actividades;
    }

    public ArrayList<LearningPath> getLearningPaths() {
        HashMap<Integer, LearningPath> learningPaths = gestorLearningPaths.getLearningPaths();
        ArrayList<LearningPath> learningPathsList = new ArrayList<>();
        for (LearningPath learningPath : learningPaths.values()) {
            learningPathsList.add(learningPath);
        }
        return learningPathsList;
    }
    
	public void agregarPrerrequisito(int learningPathId, int actividadId, int prerrequisitoId) {
		gestorLearningPaths.agregarPrerrequisito(learningPathId, actividadId, prerrequisitoId);
	}
	
	public boolean verificarPrerrequisitos(int learningPathId, int estudianteId, int actividadId) {
		return gestorLearningPaths.verificarPrerrequisitos(learningPathId, estudianteId, actividadId);
	}

	public void descompletarActividadLearningPath(int idLearningPath, int idEstudiante, int idActividad) {
		gestorLearningPaths.cambiarProgresoActividad(idLearningPath, idActividad, idEstudiante, 0);
	}
	
	public void responderActividad(int idLearningPath, int idEstudiante, int idActividad, String respuesta) {
		gestorLearningPaths.responderActividad(idLearningPath, idEstudiante, idActividad, respuesta);
		gestorLearningPaths.cambiarProgresoActividad(idLearningPath, idActividad, idEstudiante, 1);
	}
	
	public ArrayList<Usuario> getEstudiantesPorLearningPath(int learningPathId) {
		ArrayList<Usuario> estudiantes = new ArrayList<>();
		for (Integer estudianteId : gestorLearningPaths.getEstudiantesInscritos().get(learningPathId)) {
			estudiantes.add(gestorUsuarios.obtenerUsuario(estudianteId));
		}
		return estudiantes;
	}

	public String verRespuestasActividad(int idLearningPath, int idEstudiante, int idActividad) {
		return gestorLearningPaths.verRespuestasActividad(idLearningPath, idEstudiante, idActividad);
		
	}

	public Boolean verificarActividadCompletada(int idLearningPath, int idEstudiante, int idActividad) {
		return gestorLearningPaths.verificarActividadCompletada(idLearningPath, idEstudiante, idActividad);
	}

	public void aprobarActividad(int idLearningPath, int idEstudiante, int idActividad) {
		gestorLearningPaths.cambiarProgresoActividad(idLearningPath, idActividad, idEstudiante, 2);
	}

	public void rechazarActividad(int idLearningPath, int idEstudiante, int idActividad) {
		gestorLearningPaths.cambiarProgresoActividad(idLearningPath, idActividad, idEstudiante, 0);
	}

	public ArrayList<LearningPath> getLearningPathsProfesor(int idProfesor) {
		ArrayList<LearningPath> learningPaths = new ArrayList<>();
		for (LearningPath learningPath : gestorLearningPaths.getLearningPaths().values()) {
			if (learningPath.getAutor() == idProfesor) {
				learningPaths.add(learningPath);
			}
		}
		return learningPaths;
	}
}   
