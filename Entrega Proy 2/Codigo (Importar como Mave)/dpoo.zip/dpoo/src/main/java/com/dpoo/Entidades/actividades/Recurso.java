package com.dpoo.Entidades.actividades;

import java.util.ArrayList;

import com.dpoo.Entidades.Actividad;

public class Recurso extends Actividad{
    private String recurso;
    private String tipoRecurso;
    private static boolean necesitaRespuesta = false;

    public Recurso(String nombre, String descripcion, String objetivo, String nivel, int duracion, int autorId, String recurso, String tipoRecurso) {
        super(nombre, descripcion, objetivo, nivel,duracion, autorId);
        this.recurso = recurso;
        this.tipoRecurso = tipoRecurso;
    }
    public Recurso(int id, String nombre, String descripcion, String objetivo, String nivel, int duracion, int autorId, String recurso, String tipoRecurso) {
        super(id, nombre, descripcion, objetivo, nivel,duracion, autorId);
        this.recurso = recurso;
        this.tipoRecurso = tipoRecurso;
    }
    @Override
    public String getTipo() {
        return "Recurso";
    }
    @Override
    public String getContenido() {
        return "Revisar el recurso: " + recurso;
    }
    @Override
    public Actividad copiar(int autorId) {
        return new Recurso(this.nombre, this.descripcion, this.objetivo, this.nivel, this.duracion, autorId, this.recurso, this.tipoRecurso);
    }

    @Override
    public String toString(){
        String formato = super.toString();
        formato += "Recurso\n";
        formato += recurso + "\n";
        formato += tipoRecurso + "\n";
        return formato;
    }

    public static Recurso fromStringArray(String[] data) {
        if (data.length < 10) {
            throw new IllegalArgumentException("Datos insuficientes para crear una instancia de Recurso.");
        }
    
        int id = Integer.parseInt(data[0]);
        String nombre = data[1];
        String descripcion = data[2];
        String objetivo = data[3];
        String nivel = data[4];
        int duracion = Integer.parseInt(data[5]);
        int autorId = Integer.parseInt(data[6]);
        String recurso = data[8]; // El recurso específico
        String tipoRecurso = data[9]; // El tipo de recurso
    
        return new Recurso(id, nombre, descripcion, objetivo, nivel, duracion, autorId, recurso, tipoRecurso);
    }
    
    public String getRecurso() {
        return recurso;
    }

    public void setRecurso(String recurso) {
        this.recurso = recurso;
    }

    public String getTipoRecurso() {
        return tipoRecurso;
    }

    public void setTipoRecurso(String tipoRecurso) {
        this.tipoRecurso = tipoRecurso;
    }
    @Override
    public ArrayList<String> getParametros() {
        ArrayList<String> parametros = new ArrayList<>();
        parametros.add("Recurso");
        parametros.add("Tipo de recurso");
        return parametros;
    }
    
    @Override
	public boolean necesitaRespuesta() {
		return necesitaRespuesta;
	}
}
