package com.dpoo.Entidades.actividades;

import java.util.ArrayList;

import com.dpoo.Entidades.Actividad;

public class Examen extends Actividad{
    private ArrayList<String> preguntas = new ArrayList<>();
    private int puntajeMinimo;
    private final boolean necesitaRespuesta = true;

    public Examen(int id, String nombre, String descripcion, String objetivo, String nivel, int duracion, int puntajeMinimo, int autorId) {
        super(id, nombre, descripcion, objetivo, nivel,duracion, autorId);
        this.puntajeMinimo = puntajeMinimo;
    }

    public Examen(String nombre, String descripcion, String objetivo, String nivel, int duracion,int puntajeMinimo, int autorId) {
        super(nombre, descripcion, objetivo, nivel,duracion, autorId);
        this.puntajeMinimo = puntajeMinimo;
    }

    public Examen(Actividad actividad, int puntajeMinimo) {
        super(actividad.getId(), actividad.getNombre(), actividad.getDescripcion(), actividad.getObjetivo(), actividad.getNivel(), actividad.getDuracion(), actividad.getAutorId());
        this.puntajeMinimo = puntajeMinimo;
    }

    @Override
    public String getTipo() {
        return "Examen";
    }

    @Override
    public String getContenido() {
        String retorno= "Realizar el examen: \n";
        for (String pregunta : preguntas) {
            retorno = retorno + pregunta + "\n";
        }

        return retorno;
    }

    @Override
    public Actividad copiar(int autorId) {
        Examen copia = new Examen(this.nombre, this.descripcion, this.objetivo, this.nivel, this.duracion, this.puntajeMinimo, autorId);
        copia.setPreguntas(this.preguntas);
        return copia;
    }

    @Override
    public String toString(){
        String formato = super.toString();
        formato += "Examen\n";
        for (String pregunta : preguntas) {
            formato += pregunta + "\n";
        }
        formato += puntajeMinimo + "\n";
        return formato;
    }

    public static Examen fromStringArray(String[] data) {
        // Verificamos que el array tenga suficientes elementos
        if (data.length < 9) {
            throw new IllegalArgumentException("Datos insuficientes para crear una instancia de Examen.");
        }
    
        // Parseamos los datos básicos
        int id = Integer.parseInt(data[0]);
        String nombre = data[1];
        String descripcion = data[2];
        String objetivo = data[3];
        String nivel = data[4];
        int duracion = Integer.parseInt(data[5]);
        int autorId = Integer.parseInt(data[6]);
    
        // Última línea específica del Examen contiene el puntaje mínimo
        int puntajeMinimo = Integer.parseInt(data[data.length - 1]);
    
        // Crear la instancia de Examen
        Examen examen = new Examen(id, nombre, descripcion, objetivo, nivel, duracion, puntajeMinimo, autorId);
    
        // Agregar preguntas que se encuentran después de la línea "Examen"
        for (int i = 8; i < data.length - 1; i++) {
            examen.getPreguntas().add(data[i]);
        }
    
        return examen;
    }
    
    public ArrayList<String> getPreguntas() {
        return preguntas;
    }

    public void setPreguntas(ArrayList<String> preguntas) {
        this.preguntas = preguntas;
    }

    public int getPuntajeMinimo() {
        return puntajeMinimo;
    }

    public void setPuntajeMinimo(int puntajeMinimo) {
        this.puntajeMinimo = puntajeMinimo;
    }

    @Override
    public ArrayList<String> getParametros() {
        ArrayList<String> parametros = new ArrayList<>();
        parametros.add("Examen");
        return parametros;
    }
    
    @Override
	public boolean necesitaRespuesta() {
		return necesitaRespuesta;
	}
}
