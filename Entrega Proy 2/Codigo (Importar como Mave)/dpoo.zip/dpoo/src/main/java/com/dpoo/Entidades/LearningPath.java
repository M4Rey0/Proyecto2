package com.dpoo.Entidades;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class LearningPath {
    private int id;
    private String nombre;
    private String descripcion;
    private int duracion;
    private HashMap<Integer, Actividad> actividades = new HashMap<>();
    private HashMap<Integer, ArrayList<Integer>> prerrequisitos = new HashMap<>();
    private HashMap<Integer, HashMap<Integer, Integer>> recomendadas = new HashMap<>();
    private ArrayList<Integer> estudiantes = new ArrayList<>();
    private LocalDate fechaCreacion;
    private LocalDate fechaModificacion;
    private int autor;
    private int version;
    //Estructura de recomendadas: <actividadId, <despues/antes, actividadId >>

    private static int idCounter = 0;

    private static int generateId() {
        return ++idCounter;
    }

    private static int useId(int id){
        if (id > idCounter) {
            idCounter = id;
        }
        return id;
    }

    public LearningPath(int id, String nombre, String descripcion, int duracion, LocalDate fechaCreacion, LocalDate fechaModificacion, int version, int autor) {
        this.id = useId(id);
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.duracion = duracion;
        this.fechaCreacion = fechaCreacion;
        this.fechaModificacion = fechaModificacion;
        this.version = version;
        this.autor = autor;
    }

    public LearningPath(String nombre, String descripcion, int duracion, LocalDate fechaCreacion, LocalDate fechaModificacion, int version, int autor) {
        this.id = generateId();
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.duracion = duracion;
        this.fechaCreacion = fechaCreacion;
        this.fechaModificacion = fechaModificacion;
        this.version = version;
        this.autor = autor;
    }

    public void agregarActividad(Actividad actividad){
        if (!actividades.containsKey(actividad.getId())) {
            duracion += actividad.getDuracion();
        } else {
            duracion += actividad.getDuracion() - actividades.get(actividad.getId()).getDuracion();
        }
        actividades.put(actividad.getId(), actividad);
    }

    public void agregarPrerrequisito(int actividadId, int prerrequisitoId){
        if (!prerrequisitos.containsKey(actividadId)) {
            prerrequisitos.put(actividadId, new ArrayList<>());
        }
        prerrequisitos.get(actividadId).add(prerrequisitoId);
    }

    /**
     * Agrega una actividad recomendada a una actividad, antes o despues
     * @param actividadId
     * @param recomendadaId
     * @param tipo 0: antes, 1: despues
     */
    public void agregarRecomendada(int actividadId, int recomendadaId, int tipo){
        if (!recomendadas.containsKey(actividadId)) {
            recomendadas.put(actividadId, new HashMap<>());
        }
        recomendadas.get(actividadId).put(tipo, recomendadaId);
    }

    public void agregarEstudiante(int estudianteId){
        estudiantes.add(estudianteId);
    }

    public void removerEstudiante(int estudianteId){
		for (int i = 0; i < estudiantes.size(); i++) {
			if (estudiantes.get(i) == estudianteId) {
				estudiantes.remove(i);
				break;
			}
		}
    }

    public void removerActividad(int actividadId){
        actividades.remove(actividadId);
    }

    public void removerPrerrequisito(int actividadId, int prerrequisitoId){
        if (prerrequisitos.containsKey(actividadId)) {
            ArrayList<Integer> prerrequisitosActividad = prerrequisitos.get(actividadId);
			for (int i = 0; i < prerrequisitosActividad.size(); i++) {
				if (prerrequisitosActividad.get(i) == prerrequisitoId) {
                    prerrequisitosActividad.remove(i);
                    break;
				}
			}
        }
    }

    @Override
    public String toString(){
        String formato = "";
        formato += id + "\n";
        formato += nombre + "\n";
        formato += descripcion + "\n";
        formato += duracion + "\n";
        formato += fechaCreacion + "\n";
        formato += fechaModificacion + "\n";
        formato += version + "\n";
        formato += autor + "\n";
        for (Actividad actividad : actividades.values()) {
            formato += actividad.getId() + "\n";
        }
        formato += "Prerrequisitos\n";
        for (Integer key : prerrequisitos.keySet()) {
            for (Integer prerrequisito : prerrequisitos.get(key)) {
                formato += key + " " + prerrequisito + "\n";
            }
        }
        formato += "Recomendadas\n";
        for (Integer key : recomendadas.keySet()) {
            for (Integer tipo : recomendadas.get(key).keySet()) {
                for (Integer recomendada : recomendadas.get(key).values()) {
                    formato += key + " " + tipo + " " + recomendada + "\n";
                }
            }
        }
        formato += "Estudiantes\n";
        for (Integer estudiante : estudiantes) {
            formato += estudiante + "\n";
        }
        return formato;
    }

    public static LearningPath cargarDesdeString(String[] data, HashMap<Integer, Actividad> actividadesMap) {
        int index = 0;
        
        // Cargar atributos básicos
        int id = Integer.parseInt(data[index++]);
        String nombre = data[index++];
        String descripcion = data[index++];
        int duracion = Integer.parseInt(data[index++]);
        LocalDate fechaCreacion = LocalDate.parse(data[index++]);
        LocalDate fechaModificacion = LocalDate.parse(data[index++]);
        int version = Integer.parseInt(data[index++]);
        int autor = Integer.parseInt(data[index++]);
    
        // Crear el LearningPath con los datos básicos
        LearningPath learningPath = new LearningPath(id, nombre, descripcion, duracion, fechaCreacion, fechaModificacion, version, autor);
    
        // Cargar actividades
        while (!data[index].equals("Prerrequisitos")) {
            int actividadId = Integer.parseInt(data[index++]);
            if (actividadesMap.containsKey(actividadId)) {
                learningPath.agregarActividad(actividadesMap.get(actividadId));
            }
        }
    
        // Cargar prerrequisitos
        index++; // Saltar el "Prerrequisitos"
        while (!data[index].equals("Recomendadas")) {
            String[] prerrequisitoData = data[index++].split(" ");
            int actividadId = Integer.parseInt(prerrequisitoData[0]);
            int prerrequisitoId = Integer.parseInt(prerrequisitoData[1]);
            learningPath.agregarPrerrequisito(actividadId, prerrequisitoId);
        }
    
        // Cargar recomendadas
        index++; // Saltar el "Recomendadas"
        while (!data[index].equals("Estudiantes")) {
            String[] recomendadaData = data[index++].split(" ");
            int actividadId = Integer.parseInt(recomendadaData[0]);
            int tipo = Integer.parseInt(recomendadaData[1]);
            int recomendadaId = Integer.parseInt(recomendadaData[2]);
            learningPath.agregarRecomendada(actividadId, recomendadaId, tipo);
        }
    
        // Cargar estudiantes
        index++; // Saltar el "Estudiantes"
        while (index < data.length) {
            int estudianteId = Integer.parseInt(data[index++]);
            learningPath.agregarEstudiante(estudianteId);
        }
    
        return learningPath;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public HashMap<Integer, Actividad> getActividades() {
        return actividades;
    }

    public void setActividades(HashMap<Integer, Actividad> actividades) {
        this.actividades = actividades;
    }

    public HashMap<Integer, ArrayList<Integer>> getPrerrequisitos() {
        return prerrequisitos;
    }

    public void setPrerrequisitos(HashMap<Integer, ArrayList<Integer>> prerrequisitos) {
        this.prerrequisitos = prerrequisitos;
    }

    public HashMap<Integer, HashMap<Integer, Integer>> getRecomendadas() {
        return recomendadas;
    }

    public void setRecomendadas(HashMap<Integer, HashMap<Integer, Integer>> recomendadas) {
        this.recomendadas = recomendadas;
    }

    public ArrayList<Integer> getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(ArrayList<Integer> estudiantes) {
        this.estudiantes = estudiantes;
    }

    public LocalDate getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDate fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public LocalDate getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(LocalDate fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }
    
	public int getAutor() {
		return autor;
	}
	
	public void setAutor(int autor) {
		this.autor = autor;
	}
    
}
