package com.dpoo.Entidades.actividades;

import java.util.ArrayList;

import com.dpoo.Entidades.Actividad;

public class Tarea extends Actividad {
    private String tarea;
    private static boolean necesitaRespuesta = true;

    public Tarea(String nombre, String descripcion, String objetivo, String nivel, int duracion, String tarea, int autorId) {
        super(nombre, descripcion, objetivo, nivel,duracion, autorId);
        this.tarea = tarea;
    }

    public Tarea(int id, String nombre, String descripcion, String objetivo, String nivel, int duracion, String tarea, int autorId) {
        super(id, nombre, descripcion, objetivo, nivel,duracion, autorId);
        this.tarea = tarea;
    }

    @Override
    public String getTipo() {
        return "Tarea";
    }

    @Override
    public String getContenido() {
        return "Realizar la tarea: " + tarea;
    }

    @Override
    public Actividad copiar(int autorId) {
        return new Tarea(this.nombre, this.descripcion, this.objetivo, this.nivel, this.duracion, this.tarea, autorId);
    }

    @Override
    public String toString(){
        String formato = super.toString();
        formato += "Tarea\n";
        formato += tarea + "\n";
        return formato;
    }

    public static Tarea fromStringArray(String[] data) {
        if (data.length < 8) {
            throw new IllegalArgumentException("Datos insuficientes para crear una instancia de Tarea.");
        }
    
        // Parsear el id y el autorId como enteros
        int id = Integer.parseInt(data[0]);
        String nombre = data[1];
        String descripcion = data[2];
        String objetivo = data[3];
        String nivel = data[4];
        int duracion = Integer.parseInt(data[5]);
        int autorId = Integer.parseInt(data[6]);
        String tarea = data[8];
    
        return new Tarea(id, nombre, descripcion, objetivo, nivel, duracion, tarea, autorId);
    }
    
    public String getTarea() {
        return tarea;
    }

    public void setTarea(String tarea) {
        this.tarea = tarea;
    }

    @Override
    public ArrayList<String> getParametros() {
        ArrayList<String> parametros = new ArrayList<>();
        parametros.add("Tarea");
        return parametros;
    }
    
	@Override
	public boolean necesitaRespuesta() {
		return necesitaRespuesta;
	}
}
