package com.dpoo.Entidades;

public abstract class Usuario {

    protected int id;
    protected String nombre;
    protected String username;
    protected String password;
    private static int idCounter = 0;

    public Usuario(int id, String nombre, String username, String password) {
        this.id = id;
        useId(id);
        this.nombre = nombre;
        this.username = username;
        this.password = password;
    }

    public Usuario(String nombre, String username, String password) {
        this.id = generateId();
        this.nombre = nombre;
        this.username = username;
        this.password = password;
    }

    public abstract String getTipo();

    public boolean validatePassword(String password) {
        return this.password.equals(password);
    }

    private static void useId(int id){
        if (id > idCounter) {
            idCounter = id;
        }
    }

    private static int generateId() {
        return ++idCounter;
    }

    @Override
    public String toString(){
        String formato = "";
        formato += id + "\n";
        formato += nombre + "\n";
        formato += username + "\n";
        formato += password + "\n";
        return formato;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
