package com.dpoo.Gestores;

import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.Usuario;
import com.dpoo.Entidades.usuarios.Estudiante;
import com.dpoo.Entidades.usuarios.Profesor;
import com.dpoo.Persistencia.usuarios.PersistenciaUsuarios;

public class GestorUsuarios {
    private HashMap<Integer, Usuario> usuarios = new HashMap<>();
    private HashMap<String, Integer> usuariosByUsername = new HashMap<>();
    private HashMap<Integer, Estudiante> estudiantes = new HashMap<>();
    private HashMap<Integer, Profesor> profesores = new HashMap<>();

    public void agregarUsuario(Usuario usuario) {
        usuarios.put(usuario.getId(), usuario);
        usuariosByUsername.put(usuario.getUsername(), usuario.getId());
        if (usuario.getTipo().equals("Estudiante")) {
            estudiantes.put(usuario.getId(), (Estudiante) usuario);
        } else if (usuario.getTipo().equals("Profesor")) {
            profesores.put(usuario.getId(), (Profesor) usuario);
        }
        PersistenciaUsuarios.guardarUsuario(usuario);
    }

    public Usuario obtenerUsuario(int id) {
        return usuarios.get(id);
    }

    public Usuario obtenerUsuario(String username) {
        return usuarios.get(usuariosByUsername.get(username));
    }

    public void borrarUsuario(int id) {
        Usuario usuario = usuarios.get(id);
        usuarios.remove(id);
        usuariosByUsername.remove(usuario.getUsername());
        if (usuario.getTipo().equals("Estudiante")) {
            estudiantes.remove(id);
        } else if (usuario.getTipo().equals("Profesor")) {
            profesores.remove(id);
        }
    }

    public void quitarActividad(int idProfesor, Actividad actividad) {
        profesores.get(idProfesor).removeActividad(actividad);
        PersistenciaUsuarios.guardarUsuario(profesores.get(idProfesor));
    }

    public void cargarUsuarios(HashMap<Integer, Actividad> actividades) {
        usuarios = PersistenciaUsuarios.cargarUsuarios(actividades);
        for (Usuario usuario : usuarios.values()) {
            usuariosByUsername.put(usuario.getUsername(), usuario.getId());
            if (usuario.getTipo().equals("Estudiante")) {
                estudiantes.put(usuario.getId(), (Estudiante) usuario);
            } else if (usuario.getTipo().equals("Profesor")) {
                profesores.put(usuario.getId(), (Profesor) usuario);
            }
        }
    }

    public Usuario validarUsuario(String username, String password) {
        if (usuariosByUsername.containsKey(username)) {
            Usuario usuario = usuarios.get(usuariosByUsername.get(username));
            if (usuario.validatePassword(password)) {
                return usuario;
            }
        }

        return null;
    }

    public Profesor obtenerProfesor(int profesorId) {
        return profesores.get(profesorId);
    }

    public void agregarActividad(int autorId, Actividad actividad) {
    	
        profesores.get(autorId).addActividad(actividad);
        PersistenciaUsuarios.guardarUsuario(profesores.get(autorId));
    }

    public HashMap<Integer, Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(HashMap<Integer, Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public HashMap<String, Integer> getUsuariosByUsername() {
        return usuariosByUsername;
    }

    public void setUsuariosByUsername(HashMap<String, Integer> usuariosByUsername) {
        this.usuariosByUsername = usuariosByUsername;
    }

    public HashMap<Integer, Estudiante> getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(HashMap<Integer, Estudiante> estudiantes) {
        this.estudiantes = estudiantes;
    }

    public HashMap<Integer, Profesor> getProfesores() {
        return profesores;
    }

    public void setProfesores(HashMap<Integer, Profesor> profesores) {
        this.profesores = profesores;
    }

	public void inscribirEstudianteLearningPath(int estudianteId, int learningPathId) {
		System.out.println(estudianteId);
		estudiantes.get(estudianteId).addLearningPath(learningPathId);
        PersistenciaUsuarios.guardarUsuario(estudiantes.get(estudianteId));
	}
}
