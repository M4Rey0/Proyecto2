package com.dpoo.Entidades;

import java.util.ArrayList;

public abstract class Actividad {
    protected int id;
    protected String nombre;
    protected String descripcion;
    protected String objetivo;
    protected String nivel;
    protected int duracion; //en minutos
    protected int autorId;

    private static int idCounter = 0;
    
    public abstract String getTipo();
    public abstract String getContenido();
    public abstract Actividad copiar(int autorId);

    public Actividad(int id, String nombre, String descripcion, String objetivo, String nivel, int duracion, int autorId) {
        this.id = useId(id);
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.objetivo = objetivo;
        this.nivel = nivel;
        this.duracion = duracion;
        this.autorId = autorId;
    }

    public Actividad(String nombre, String descripcion, String objetivo, String nivel, int duracion, int autorId) {
        this.id = generateId();
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.objetivo = objetivo;
        this.nivel = nivel;
        this.duracion = duracion;
        this.autorId = autorId;
    }

    public abstract ArrayList<String> getParametros();

    private static int generateId() {
        return ++idCounter;
    }

    private static int useId(int id){
        if (id > idCounter) {
            idCounter = id;
        }
        return id;
    }

    @Override
    public String toString(){
        String formato = "";
        formato += id + "\n";
        formato += nombre + "\n";
        formato += descripcion + "\n";
        formato += objetivo + "\n";
        formato += nivel + "\n";
        formato += duracion + "\n";
        formato += autorId + "\n";
        return formato;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public int getAutorId() {
        return autorId;
    }

    public void setAutorId(int autorId) {
        this.autorId = autorId;
    }
    
    public abstract boolean necesitaRespuesta();
}
