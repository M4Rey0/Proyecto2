package com.dpoo.Estructuras;

import java.util.HashMap;

import com.dpoo.Entidades.LearningPath;
import com.dpoo.Entidades.usuarios.Estudiante;

public class ProgresoLearningPath {
    private LearningPath learningPath;
    private int estudiante;
    private int progreso;

    private HashMap<Integer, Integer> progresoPorActividad = new HashMap<>();
    private HashMap<Integer, String> respuestaPorActividad = new HashMap<>();
    
    // Estructura de progresoPorActividad: <actividadId, progreso>, progreso puede
    // ser 0: sin hacer, 1: en progreso, 2: completada

    public ProgresoLearningPath(LearningPath learningPath, int estudiante) {
        this.learningPath = learningPath;
        this.estudiante = estudiante;
        this.progreso = 0;
        for (Integer actividadId : learningPath.getActividades().keySet()) {
            progresoPorActividad.put(actividadId, 0);
        }
    }

    public void cambiarProgresoActividad(int actividadId, int progreso) {
        progresoPorActividad.put(actividadId, progreso);
        calcularProgreso();
    }
    
	public boolean verificarActividadCompletada(int actividadId) {
		return progresoPorActividad.get(actividadId) == 2;
	}

    private void calcularProgreso() {
        int completadas = 0;
        for (Integer progreso : progresoPorActividad.values()) {
            if (progreso == 2) {
                completadas++;
            }
        }
        this.progreso = (completadas * 100) / progresoPorActividad.size();
    }

    @Override
    public String toString() {
        String formato = "";
        formato += learningPath.getId() + "\n";
        formato += estudiante + "\n";
        formato += progreso + "\n";
        for (Integer actividadId : progresoPorActividad.keySet()) {
            formato += actividadId + " " + progresoPorActividad.get(actividadId) + "\n";
        }

        return formato;
    }
    
    public String respuestaToString(int idActividad) {
		return respuestaPorActividad.get(idActividad);
    }
    
    public void agregarRespuesta(int idActividad, String respuesta) {
    	respuestaPorActividad.put(idActividad, respuesta);
    }

    public static ProgresoLearningPath cargarDesdeString(String[] contenido,
            HashMap<Integer, LearningPath> learningPaths, HashMap<Integer, Estudiante> estudiantes) {
        try {
            // Obtener el ID del LearningPath y buscarlo en el HashMap
            int learningPathId = Integer.parseInt(contenido[0]);
            LearningPath learningPath = learningPaths.get(learningPathId);

            // Obtener el ID del Estudiante y buscarlo en el HashMap
            int estudianteId = Integer.parseInt(contenido[1]);
            Estudiante estudiante = estudiantes.get(estudianteId);

            // Crear el objeto ProgresoLearningPath
            ProgresoLearningPath progresoLearningPath = new ProgresoLearningPath(learningPath, estudiante.getId());

            // Establecer el progreso general
            progresoLearningPath.setProgreso(Integer.parseInt(contenido[2]));

            // Cargar progreso por actividad
            for (int i = 3; i < contenido.length; i++) {
                String[] progresoData = contenido[i].split(" ");
                int actividadId = Integer.parseInt(progresoData[0]);
                int progreso = Integer.parseInt(progresoData[1]);
                progresoLearningPath.getProgresoPorActividad().put(actividadId, progreso);
            }

            return progresoLearningPath;
        } catch (Exception e) {
            System.err.println("Error al cargar ProgresoLearningPath desde String[]: " + e.getMessage());
            return null;
        }
    }

    public LearningPath getLearningPath() {
        return learningPath;
    }

    public void setLearningPath(LearningPath learningPath) {
        this.learningPath = learningPath;
    }

    public int getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(int estudiante) {
        this.estudiante = estudiante;
    }

    public int getProgreso() {
        return progreso;
    }

    public void setProgreso(int progreso) {
        this.progreso = progreso;
    }

    public HashMap<Integer, Integer> getProgresoPorActividad() {
        return progresoPorActividad;
    }

    public void setProgresoPorActividad(HashMap<Integer, Integer> progresoPorActividad) {
        this.progresoPorActividad = progresoPorActividad;
    }

	public void cargarRespuestaFromString(String content, Integer actividadId) {
		respuestaPorActividad.put(actividadId, content);
	}

	public String getRespuestaPorActividad(int idActividad) {
		return respuestaPorActividad.get(idActividad);
	}

	public void quitarProgresoActividad(int actividadId) {
		progresoPorActividad.remove(actividadId);
	}
}
